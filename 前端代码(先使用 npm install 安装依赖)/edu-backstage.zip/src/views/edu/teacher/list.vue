<template>
  <div class="app-container">
    <!-- 讲师表单 -->

    <!--查询表单-->
    <el-form :inline="true" class="demo-form-inline">
      <el-form-item>
        <el-input v-model="teacherQuery.name" placeholder="讲师名"/>
      </el-form-item>

      <el-form-item>
        <el-select v-model="teacherQuery.level" clearable placeholder="讲师头衔">
          <el-option :value="1" label="高级讲师"/>
          <el-option :value="2" label="首席讲师"/>
        </el-select>
      </el-form-item>

      <el-form-item label="添加时间">
        <el-date-picker
          v-model="teacherQuery.begin"
          type="datetime"
          placeholder="选择开始时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          default-time="00:00:00"
        />
      </el-form-item>
      <el-form-item>
        <el-date-picker
          v-model="teacherQuery.end"
          type="datetime"
          placeholder="选择截止时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          default-time="00:00:00"
        />
      </el-form-item>

      <el-button type="primary" icon="el-icon-search" @click="getList()">查询</el-button>
      <el-button type="default" @click="resetData()">清空</el-button>
    </el-form>

    <!-- 表格 -->
    <el-table
      :data="list"
      v-loading="loading"
      element-loading-text="数据加载中"
      border
      fit
      highlight-current-row>

      <el-table-column
        label="序号"
        width="70"
        align="center">
        <template slot-scope="scope">
          {{ (current - 1) * size + scope.$index + 1 }}
        </template>
      </el-table-column>

      <el-table-column prop="name" label="名称" width="80" />

      <el-table-column label="头衔" width="80">
        <template slot-scope="scope">
          {{ scope.row.level===1?'高级讲师':'首席讲师' }}
        </template>
      </el-table-column>

      <el-table-column prop="intro" label="资历" />

      <el-table-column prop="gmtCreate" label="添加时间" width="160"/>

      <el-table-column prop="sort" label="排序" width="60" />

      <el-table-column label="操作" width="200" align="center">
        <template slot-scope="scope">
          <router-link :to="'/teacher/edit/'+scope.row.id">
            <el-button type="primary" size="mini" icon="el-icon-edit">修改</el-button>
          </router-link>
          <el-button type="danger" size="mini" icon="el-icon-delete" @click="removeDataById(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>>
      <!-- 分页 @current-change相当于绑定了一个单机函数getList,
      框架已经封装好了方法不用加括号或者参数自动传参-->
    <el-pagination
      :current-page="current" 
      :page-size="size"
      :total="total"
      style="padding: 30px 0; text-align: center;"
      layout="total, prev, pager, next, jumper"
      @current-change="getList"
    />
  </div>
</template>


<script>
//引入写好的js函数
import teacher from "@/api/edu/teacher";

export default {
  //写核心代码
  data() {
    //定义变量和初始值
    return {
      list: null, //查询之后返回的结果,注意是个[] 踩过坑
      total: 0,
      current: 1, //当前页
      size: 7, //每页数量
      teacherQuery: {}, //查询条件
      loading: false,
    };
  },
  created() {
    //页面渲染前执行,一般调用methods中的方法
    this.getList();
  },
  methods: {
    //定义的方法
    //getList 需要有一个默认参数current来为接受查询当前的页码
    getList(current=1) {
        this.current=current
      teacher
        .getTeacherPageCondition(this.current, this.size, this.teacherQuery)
        .then(response => {
          // console.log(response)
          this.list = response.data.rows;
          this.total = response.data.total;
          console.log(this.list);
        })
        .catch(error => {
          console.log(error);
        })
    },
    closeLoading(){
        this.loading=false
    },
    resetData(){
      this.teacherQuery={}
      this.getList()
    },
    removeDataById(id){
      this.$confirm('此操作将删除该讲师, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {   //点击确定是执行
          //这里调用具体的删除函数
          teacher.removeTeacherByIdLogic(id)
          //再回调显示函数
          this.getList() 
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => { //点击取消时执行
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
    }
  },
  mounted(){
    // this.closeLoading();
  }
};
</script>