<template>
  <div class="app-container">
    <h2 style="text-align: center;">发布新课程</h2>

    <el-steps :active="2" process-status="wait" align-center style="margin-bottom: 40px;">
      <el-step title="填写课程基本信息" />
      <el-step title="创建课程大纲" />
      <el-step title="最终发布" />
    </el-steps>
    <!-- <el-button type="text" @click="openChapterDialog()">添加章节</el-button> -->

    <!-- 章节 -->
    <ul class="chanpterList">
      <li v-for="chapter in chapterNestedList" :key="chapter.id">
        <p>
          {{ chapter.title }}
          <span class="acts">
            <el-button style type="text" @click="openVideo(chapter.id)">添加小节</el-button>
            <el-button style type="text" @click="openEditChatper(chapter.id)">编辑</el-button>
            <el-button type="text" @click="removeChapter(chapter.id)">删除</el-button>
          </span>
        </p>

        <!-- 视频 -->
        <ul class="chanpterList videoList">
          <li v-for="video in chapter.videoVoList" :key="video.id">
            <p>
              {{ video.title }}
              <span class="acts">
                <el-button style type="text" @click="updateVideo(video,chapter)">编辑</el-button>
                <el-button type="text" @click="removeVideo(video.id)">删除</el-button>
              </span>
            </p>
          </li>
        </ul>
      </li>
    </ul>

    <!-- <el-button type="text" @click="dialogVideoFormVisible = true; chapterId = chapter.id">添加课时</el-button> -->
    <!-- 添加和修改课时表单 -->
    <el-dialog :visible.sync="dialogVideoFormVisible" title="添加课时">
      <el-form :model="video" label-width="120px">
        <el-form-item label="课时标题">
          <el-input v-model="video.title" />
        </el-form-item>
        <el-form-item label="课时排序">
          <el-input-number v-model="video.sort" :min="0" controls-position="right" />
        </el-form-item>
        <el-form-item label="是否免费">
          <el-radio-group v-model="video.free">
            <el-radio :label="true">免费</el-radio>
            <el-radio :label="false">默认</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="上传视频">
          <!-- TODO -->
        </el-form-item>

        <el-form-item label="上传视频">
          <el-upload
            :on-success="handleVodUploadSuccess"
            :on-remove="handleVodRemove"
            :before-remove="beforeVodRemove"
            :on-exceed="handleUploadExceed"
            :file-list="fileList"
            :action="BASE_API+'/eduvod/uploadVideoAli'"
            :limit="1"
            class="upload-demo"
          >
            <el-button size="small" type="primary">上传视频</el-button>
            <el-tooltip placement="right-end">
              <div slot="content">
                最大支持1G，
                <br />支持3GP、ASF、AVI、DAT、DV、FLV、F4V、
                <br />GIF、M2T、M4V、MJ2、MJPEG、MKV、MOV、MP4、
                <br />MPE、MPG、MPEG、MTS、OGG、QT、RM、RMVB、
                <br />SWF、TS、VOB、WMV、WEBM 等视频格式上传
              </div>
              <i class="el-icon-question" />
            </el-tooltip>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogVideoFormVisible = false">取 消</el-button>
        <el-button :disabled="saveVideoBtnDisabled" type="primary" @click="saveOrUpdateVideo">确 定</el-button>
      </div>
    </el-dialog>

    <!--章节 -->
    <!--dialogChapterFormVisible 值将会决定章节表单是否显示-->
    <el-button type="text" @click="openChapterDialog">添加章节</el-button>

    <!-- 添加和修改章节表单 -->
    <el-dialog :visible.sync="dialogChapterFormVisible" title="添加章节">
      <el-form :model="chapter" label-width="120px">
        <el-form-item label="章节标题">
          <el-input v-model="chapter.title" />
        </el-form-item>
        <el-form-item label="章节排序">
          <el-input-number v-model="chapter.sort" :min="0" controls-position="right" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogChapterFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveOrUpdate">确 定</el-button>
      </div>
    </el-dialog>

    <el-form label-width="120px">
      <el-form-item>
        <el-button @click="previous">返回上一步</el-button>
        <el-button :disabled="saveBtnDisabled" type="primary" @click="next">保存并下一步</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import courseApi from "@/api/edu/course";
import chapterApi from "@/api/edu/chapter";
import videoApi from "@/api/edu/video";
export default {
  data() {
    return {
      courseId: "", // 所属课程
      chapterNestedList: [], // 章节嵌套课时列表
      saveBtnDisabled: false,
      dialogChapterFormVisible: false,
      chapter: { title: "", sort: 0, id: "" },
      dialogVideoFormVisible: false,
      video: { title: "", sort: 0, free: 0, videoSourceId: "" },
      BASE_API: process.env.BASE_API // 接口API地址
    };
  },
  created() {
    this.courseId = this.$route.query.id;
    this.getChapterListByCourseId();
  },
  //vue监听,解决上面的bug
  watch: {
    $route(to, from) {
      //只要路由发生变化就会执行
      console.log("执行了吗");
    }
  },
  methods: {
    beforeVodRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    handleVodRemove(file, fileList) {
      chapterApi.deleteVideoById(this.video.videoSourceId).then(response => {
        this.video.videoSourceId = "";
        this.video.videoOriginalName = "";
        this.fileList = [];
        this.$message({
          type: "success",
          message: response.message
        });
      });
    },
    handleVodUploadSuccess(response, file, fileList) {
      console.log("response =")
      console.log(response)
      //获取文件名字
      this.video.videoOriginalName = file.name;
      //回去视频id
      this.video.videoSourceId = response.data.videoId;
    },
    //视图上传多于一个视频
    handleUploadExceed(files, fileList) {
      this.$message.warning("想要重新上传视频，请先删除已上传的视频");
    },

    //*************************小节操作****************************** */
    openVideo(chapterId) {
      this.video.title = "";
      this.video.sort = 0;
      this.video.free = 0;
      this.video.videoSourceId = "";
      this.dialogVideoFormVisible = true;
      this.video.chapterId = chapterId;
      this.fileList=[]
      this.getChapterListByCourseId()
    },
    add() {
      //设置课程id
      this.video.courseId = this.courseId;
      //保存video数据到数据库
      videoApi.addVideo(this.video).then(response => {
        //关闭弹框
        this.dialogVideoFormVisible = false;
        //提示
        this.$message({
          type: "success",
          message: "添加小节成功!"
        });
        //刷新页面
        this.getChapterListByCourseId();
        // location.reload();
      });
    },
    saveOrUpdateVideo() {
      if (!this.video.id) {
        this.add();
      } else {
        //修改操作
        videoApi.updateVideo(this.video).then(response => {
          //关闭弹框
          this.dialogVideoFormVisible = false;
          //提示
          this.$message({
            type: "success",
            message: "添加小节成功!"
          });
          //刷新页面
          this.getChapterListByCourseId();
        });
      }
    },
    removeVideo(videoId) {
      this.$confirm("此操作将删除小节, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        //点击确定，执行then方法
        //调用删除的方法
        videoApi.deleteVideo(videoId).then(response => {
          //删除成功
          //提示信息
          this.$message({
            type: "success",
            message: "删除小节成功!"
          });
          //将文件列表清空
          this.fileList=[]
          //将页面的东西给清空
          this.video.videoSourceId=''
          this.videoOriginalName=""
          //刷新页面
          this.getChapterListByCourseId();
        });
      }); //点击取消，执行catch方法
    },
    updateVideo(video, chapter) {
      //首先弹出视频框框
      this.dialogVideoFormVisible = true;
      this.video.videoSourceId = "";
      this.video = video;
      this.video.chapterId = chapter.id;
      //回显视频名字 TODO
      
      //设置课程id
      this.video.courseId = this.courseId;
    },
    //*************************章节操作****************************** */
    //添加章节
    addChapter() {
      this.chapter.courseId = this.courseId;
      //添加章节
      chapterApi.addChapter(this.chapter).then(response => {
        //关弹框
        this.dialogChapterFormVisible = false;
        this.$message({
          type: "success",
          message: "添加成功!"
        });
        //刷新数据
        this.getChapterListByCourseId();
      });
    },
    //修改章节
    updateChapter() {
      chapterApi.updateChapter(this.chapter).then(response => {
        //关闭弹框
        this.dialogChapterFormVisible = false;
        //提示
        this.$message({
          type: "success",
          message: "修改章节成功!"
        });
        //刷新页面
        this.getChapterListByCourseId();
      });
    },
    saveOrUpdate() {
      console.log(this.chapter.id);
      if (!this.chapter.id) {
        console.log("is saving....");
        console.log(this.chapter);
        this.addChapter();
      } else {
        console.log("is updating....");
        console.log(this.chapter);
        this.updateChapter();
      }
    },
    next() {
      //跳转到第三步
      this.$router.push({
        path: "/course/publish",
        query: { id: this.courseId }
      });
    },
    previous() {
      //跳转到第一步
      console.log("页面二");
      console.log(this.$route.query.id);
      //获取到了数据库返回的课程id号
      this.$router.push({
        path: `/course/info`,
        query: { id: this.$route.query.id }
      });
    },
    getChapterListByCourseId() {
      chapterApi.getChapterListByCourseId(this.courseId).then(response => {
        this.chapterNestedList = response.data.result;
      });
    },
    openChapterDialog() {
      this.dialogChapterFormVisible = true;
      this.chapter.title = "";
      this.chapter.sort = 0;
    },
    //修改章节弹框数据回显
    openEditChatper(the_chapterId) {
      this.dialogChapterFormVisible = true;
      //回显
      chapterApi.findChapterById(the_chapterId).then(response => {
        this.chapter = response.data.item;
      });
    },
    //每次的循环传来当前的chapterId
    removeChapter(chapterId) {
      this.$confirm("此操作将删除该章节, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          //点击确定是执行
          //这里调用具体的删除函数
          chapterApi.removeChapterById(chapterId).then(response => {
            //再回调显示函数
            this.getChapterListByCourseId();
            this.$message({
              type: "success",
              message: "删除成功!"
            });
          });
        })
        .catch(() => {
          //点击取消时执行
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>