import request from '@/utils/request'


export default {

    getChapterListByCourseId(courseId) {
    return request({
      url: `/eduservice/edu-chapter/getChapterByCourseId/${courseId}`,
      method: 'get'
    })
  },
  addChapter(chapter) {
    return request({
      url: `/eduservice/edu-chapter/addChapter`,
      method: 'post',
      data:chapter
    })
  },

  findChapterById(chapterId) {
    return request({
      url: `/eduservice/edu-chapter/findChapterById/${chapterId}`,
      method: 'get'
    })
  },
  updateChapter(chapter) {
    return request({
      url: `/eduservice/edu-chapter/updateChapter`,
      method: 'put',
      data:chapter
    })
  },
  removeChapterById(chapterId) {
    return request({
      url: `/eduservice/edu-chapter/removeChapterById/${chapterId}`,
      method: 'delete'
    })
  },
  deleteVideoById(id) {
    return request({
      url: `/eduvod/deleteById/${id}`,
      method: 'delete'
    })
  },

}