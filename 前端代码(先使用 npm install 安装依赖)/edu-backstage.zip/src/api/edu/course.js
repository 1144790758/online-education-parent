// 用于调用后端函数接口的js方法
import request from '@/utils/request'


export default  {

    //发送请求将封装的数据对象传到后端
    addCourseInfo(EduCourseData){
        return request({
          //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
            url: `/eduservice/edu-course/add_course_info`,
            method: 'post',
            data: EduCourseData,
          })
      },
      //根据课程id查询课程信息
    getCourseInfo(id){
        return request({
          //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
            url: `/eduservice/edu-course/get_course_info/${id}`,
            method: 'get',
          })
      },
      removeById(id){
        return request({
            //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
              url: `/eduservice/edu-course/removeById/${id}`,
              method: 'delete',
            })
      },
      //课程信息确认
      getCoursePublishVoById(courseId){
        return request({
            //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
              url: `/eduservice/edu-course/getCoursePublishVoById/${courseId}`,
              method: 'get',
            })
      },
      //课程最终发布
      updateCourseStatus(courseId){
        return request({
            //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
              url: `/eduservice/edu-course/updateCourseStatus/${courseId}`,
              method: 'put',
            })
      },
      //查询所有课程
      allCourse(){
        return request({
              url: `/eduservice/edu-course/allCourse`,
              method: 'get',
            })
      },
      //分页条件查询
      CourpageQuery(page,limit,courseQueryVo){
        return request({
              url: `/eduservice/edu-course/${page}/${limit}`,
              method: 'post',
              data:courseQueryVo
            })
      },
      //修改课程updateCourse
      updateCourse(course){
        return request({
              url: `/eduservice/edu-course/updateCourse`,
              method: 'put',
              data:course
            })
      },
      //删除课程及其关联
      deleteCourse(id){
        return request({
              url: `/eduservice/edu-course/deleteCourse/${id}`,
              method: 'delete',
            })
      },
}