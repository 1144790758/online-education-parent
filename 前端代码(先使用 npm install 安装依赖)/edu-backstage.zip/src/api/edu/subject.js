// 用于调用后端函数接口的js方法
import request from '@/utils/request'

export default  {

    //发送请求查询后端的课程分类数据
    list_subject(){
        return request({
          //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
            url: `/eduservice/edu-subject/list_subject`,
            method: 'get',
          })
      },

}