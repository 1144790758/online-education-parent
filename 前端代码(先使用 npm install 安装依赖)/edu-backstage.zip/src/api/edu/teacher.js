// 用于调用后端函数接口的js方法
import request from '@/utils/request'


//讲师分页条件查询,default默认导出的内容
export default  {
    getTeacherPageCondition(current, size,teacherQuery){
    return request({
    //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
      url: `/eduservice/edu-teacher/condition_query/${current}/${size}`,
      method: 'post',
      //后端使用@requestbody获取数据data把数据转换为json格式,如果不是就用param
      // data: {
      //   "name":teacherQuery.name,
      //   "level":teacherQuery.level,
      //   "begin":teacherQuery.begin,
      //   "end":teacherQuery.end
      // }
      data:teacherQuery
    })
  },
  //删除讲师
  removeTeacherByIdLogic(id){
    return request({
      //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
        url: `/eduservice/edu-teacher/delete/${id}`,
        method: 'delete',
      })
  },
  //添加讲师
  insertTeacher(teacherInfo){
    return request({
      url: `/eduservice/edu-teacher/add_edu`,
      method: 'post',
      data:teacherInfo
    })
  },
  //根据id查询讲师
  getTeacherById(id){
    return request({
      url: `/eduservice/edu-teacher/${id}`,
      method: 'get',
    })
  },
  //修改讲师信息,需要根据id来修改
  updateTeacherInfo(teacher,id){
    return request({
      url: `/eduservice/edu-teacher/${id}`,
      method: 'post',
      data:teacher
    })
  },
  findAllTeacher(){
    return request({
      url: `/eduservice/edu-teacher/findAllTeacher`,
      method: 'get',
    })
  },

}