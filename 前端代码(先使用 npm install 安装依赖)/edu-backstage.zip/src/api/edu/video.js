import request from '@/utils/request'

export default {

    addVideo(video) {
    return request({
      url: `/eduservice/edu-video/addVideo`,
      method: 'post',
      data:video
    })
  },
  deleteVideo(id) {
    return request({
      url: `/eduservice/edu-video/deleteVideo/${id}`,
      method: 'delete',
    })
  },
  updateVideo(video) {
    return request({
      url: `/eduservice/edu-video/updateVideo`,
      method: 'put',
      data:video
    })
  },
}