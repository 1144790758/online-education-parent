import request from '@/utils/request'

export default {
    //生成统计数据
    createStatistics(date) {
        return request({
            url: `/statistics/create_statistics__by_date/${date}`,
            method: 'get'
        })
    },
    //获取统计数据
    showChart(type,begin,end) {
        return request({
            url: `/statistics/show_chart/${type}/${begin}/${end}`,
            method: 'get'
        })
    },
}