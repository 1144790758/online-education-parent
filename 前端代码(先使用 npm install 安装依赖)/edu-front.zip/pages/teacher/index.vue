<template>
  <div id="aCoursesList" class="bg-fa of">
    <!-- 讲师列表 开始 -->
    <section class="container">
      <header class="comm-title all-teacher-title">
        <h2 class="fl tac">
          <span class="c-333">全部讲师</span>
        </h2>
        <section class="c-tab-title">
          <a id="subjectAll" title="全部" href="#">全部</a>
          <!-- <c:forEach var="subject" items="${subjectList }">
                            <a id="${subject.subjectId}" title="${subject.subjectName }" href="javascript:void(0)" onclick="submitForm(${subject.subjectId})">${subject.subjectName }</a>
          </c:forEach>-->
        </section>
      </header>
      <section class="c-sort-box unBr">
        <div>
          <!-- /无数据提示 开始-->
          <section class="no-data-wrap" v-if="data==0">
            <em class="icon30 no-data-ico">&nbsp;</em>
            <span class="c-666 fsize14 ml10 vam">没有相关数据，小编正在努力整理中...</span>
          </section>
          <!-- /无数据提示 结束-->
          <article class="i-teacher-list">
            <ul class="of">
              <li v-for="teacher in data" :key="teacher.id">
                <section class="i-teach-wrap">
                  <div class="i-teach-pic">
                    <a :href="'/teacher/'+teacher.id" :title="teacher.name" target="_blank">
                      <img :src="teacher.avatar" alt>
                    </a>
                  </div>
                  <div class="mt10 hLh30 txtOf tac">
                    <a :href="'/teacher/'+teacher.id" :title="teacher.name" target="_blank" class="fsize18 c-666">{{teacher.name}}</a>
                  </div>
                  <div class="hLh30 txtOf tac">
                    <span class="fsize14 c-999">{{teacher.career}}</span>
                  </div>
                  <div class="mt15 i-q-txt">
                    <p class="c-999 f-fA">{{teacher.intro}}</p>
                  </div>
                </section>
              </li>
            </ul>
            <div class="clear"></div>
          </article>
        </div>
        <!-- 公共分页 开始 -->
      <!-- 分页 @current-change相当于绑定了一个单机函数getList,
      框架已经封装好了方法不用加括号或者参数自动传参-->
    <el-pagination
      :current-page="current" 
      :page-size="size"
      :total="total"
      style="padding: 30px 0; text-align: center;"
      layout="total, prev, pager, next, jumper"
      @current-change="getList"
    />
        <!-- 公共分页 结束 -->
      </section>
    </section>
    <!-- /讲师列表 结束 -->
  </div>
</template>
<script>
import teacher from "@/api/teacher";
export default {
  data() {
    //定义变量和初始值
    return {
      data: {}, //查询之后返回的结果,注意是个[] 踩过坑
      total: 0,
      current: 1, //当前页
      size: 8, //每页数量
    };
  },
  created() {
    //页面渲染前执行,一般调用methods中的方法
    this.getList();
  },
  methods: {
    //定义的方法
    //getList 需要有一个默认参数current来为接受查询当前的页码
    //不写current=1默认参数会传入
    getList(current=1) {
      this.current=current
      console.log(this.size)
      teacher
        .frontTeacherPage(this.current, this.size)
        .then(response => {
          console.log(response)
          this.data = response.data.data.data.records;
          this.total = response.data.data.total;
        })
        .catch(error => {
          console.log(error);
        })
    },
    
  },
  mounted(){
    // this.closeLoading();
  }

};
</script>