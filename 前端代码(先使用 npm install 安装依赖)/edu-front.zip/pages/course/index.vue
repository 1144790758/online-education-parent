<template>
  <div id="aCoursesList" class="bg-fa of">
    <!-- /课程列表 开始 -->
    <section class="container">
      <header class="comm-title">
        <h2 class="fl tac">
          <el-button type="primary" plain @click="getAllCourse">全部课程</el-button>
        </h2>
      </header>
      <section class="c-sort-box">
        <section class="c-s-dl">
          <dl>
            <dt>
              <span class="c-999 fsize14">课程类别</span>
            </dt>
            <dd class="c-s-dl-li">
              <ul class="clearfix" >
                <li v-for="oneSubject in subjectNestedList" :key="oneSubject.id" @click="subSubjectList=oneSubject.children" >
                  <a :title="oneSubject.label"   href="#" >{{oneSubject.label}}</a>
                </li>
              </ul>
            </dd>
          </dl>
          <dl>
            <dt>
              <span class="c-999 fsize14"></span>
            </dt>
            <dd class="c-s-dl-li">
              <ul class="clearfix">
                <li  v-for="twoSubject in subSubjectList" :key="twoSubject.id">
                  <a :title="twoSubject.label" @click="getData(twoSubject.id)">{{twoSubject.label}}</a>
                </li>
              </ul>
            </dd>
          </dl>
          <div class="clear"></div>
        </section>
        <div class="js-wrap">
          <section class="fr">
            <span class="c-ccc">
              <i class="c-master f-fM">1</i>/
              <i class="c-666 f-fM">1</i>
            </span>
          </section>
          <section class="fl">
            <ol class="js-tap clearfix">
              <li>
                <el-button type="primary" @click="getByFocus">关注度</el-button>
              </li>
              <li>
                <el-button type="warning" @click="getByUpdate">最新</el-button>
              </li>
              <li>
                <el-button type="success" @click="getByUpdate">价格</el-button>
              </li>
            </ol>
          </section>
        </div>
        <div class="mt40">
          <!-- /无数据提示 开始-->
          <section class="no-data-wrap" v-if="total==0">
            <em class="icon30 no-data-ico">&nbsp;</em>
            <span class="c-666 fsize14 ml10 vam" >没有相关数据，小编正在努力整理中...</span>
          </section>
          <!-- /无数据提示 结束-->
          <article class="comm-course-list">
            <ul class="of" id="bna">
              <li v-for="course in data" :key="course.id">
                <div class="cc-l-wrap">
                  <section class="course-img">
                    <img
                      :src="course.cover"
                      class="img-responsive 图片固定大小"
                      :alt="course.title"
                    />
                    <div class="cc-mask">
                      <a :href="'/course/'+course.id" title="开始学习" class="comm-btn c-btn-1">开始学习</a>
                    </div>
                  </section>
                  <h3 class="hLh30 txtOf mt10">
                    <a :href="'/course/'+course.id" :title="course.title" class="course-title fsize18 c-333">{{course.title}}</a>
                  </h3>
                  <section class="mt10 hLh20 of">
                    <span class="fr jgTag bg-green">
                      <i class="c-fff fsize12 f-fA">{{course.price==0?"免费":course.price}}</i>
                    </span>
                    <span class="fl jgAttr c-ccc f-fA">
                      <i class="c-999 f-fA">{{course.buyCount}}</i>
                      |
                      <i class="c-999 f-fA">9634评论</i>
                    </span>
                  </section>
                </div>
              </li>
            </ul>
            <div class="clear"></div>
          </article>
        </div>
        <!-- 公共分页 开始 -->
              <!-- 分页 @current-change相当于绑定了一个单机函数getList,
      框架已经封装好了方法不用加括号或者参数自动传参-->
          <el-pagination
            :current-page="current" 
            :page-size="size"
            :total="total"
            style="padding: 30px 0; text-align: center;"
            layout="total, prev, pager, next, jumper"
            @current-change="getList"
          />
        <!-- 公共分页 结束 -->
      </section>
    </section>
    <!-- /课程列表 结束 -->
  </div>
</template>
<script>
import course from "@/api/course";
export default {
  data() {
    return {
      current: 1,
      size:8,
      data: {},
      subjectNestedList: [], // 一级分类列表
      subSubjectList: [], // 二级分类列表
      is_focus:0,
      is_update_time:0,
      is_price:0,
      oneIndex: -1,
      twoIndex: -1,
      buyCountSort: "0",
      gmtModifiedSort: "0",
      priceSort: "0",
      CourseQueryVo:{},// 查询表单对象
    };
  },

  //加载完渲染时
  created() {
    //获取课程列表
    this.getList();

    //获取分类
    this.initSubject();
  },

  methods: {
    //getList 需要有一个默认参数current来为接受查询当前的页码
    //不写current=1默认参数会传入
    //查询课程列表
    getList(current=1) {
      this.current=current
      course
        .condition_query(this.current, this.size,this.CourseQueryVo)
        .then(response => {
          console.log(response)
          this.data = response.data.data.courses;
          this.total = response.data.data.total;
        })
        .catch(error => {
          console.log(error);
        })
    },

    //查询所有一级分类
    initSubject() {
      course.list_subject().then(response => {
        this.subjectNestedList = response.data.data.result;
      });
    },

    //按照二级分类id查询
    getData(id){
      this.CourseQueryVo.subjectId=id
      this.getList()
      //查询完成后将查询对象清空
      // this.CourseQueryVo={}
    },
    //按照关注度查询
    //这里几个查询组成了一个bug,排序时是按照第一个字段排序然后第一个字段相同然后才会考虑后面的字段排序
    //说以考虑将查询排序简化每次只考虑一种排序字段
    getByFocus(){
      this.CourseQueryVo.is_focus=(this.is_focus==0?1:0)
      this.CourseQueryVo.is_update_time=""
      this.CourseQueryVo.is_price=""
      this.getList()
      this.is_focus=(this.is_focus==0?1:0)

    },
    //按照更新时间查询
    getByUpdate(){
      this.CourseQueryVo.is_update_time=(this.is_update_time==0?1:0)
      this.CourseQueryVo.is_price=""
      this.CourseQueryVo.is_focus=""
      this.getList()
      this.is_update_time=(this.is_update_time==0?1:0)
    },
    //按照价格查询
    getByPrice(){
      this.CourseQueryVo.is_price=(this.is_price==0?1:0)
      this.CourseQueryVo.is_update_time=""
      this.CourseQueryVo.is_focus=""
      this.getList()
      this.is_price=(this.is_price==0?1:0)
    },
    //查所有课程
    getAllCourse(){
      this.CourseQueryVo={}
      this.getList()
    }
  }
};
</script>
<style>
.图片固定大小 {
  width: 267.5px;
  height: 267.5px;
}
</style>