<template>
  <div id="aCoursesList" class="bg-fa of">
    <!-- /课程详情 开始 -->
    <section class="container">
      <section class="path-wrap txtOf hLh30">
        <a href="#" title class="c-999 fsize14">首页</a>
        \
        <a href="#" title class="c-999 fsize14">课程列表</a>
        \
        <span class="c-333 fsize14">{{course.title}}</span>
      </section>
      <div>
        <article class="c-v-pic-wrap" style="height: 357px;">
          <section class="p-h-video-box" id="videoPlay">
            <img height="357px" width="640px" :src="course.cover" :alt="course.title" class="dis c-v-pic " />
          </section>
        </article>
        <aside class="c-attr-wrap">
          <section class="ml20 mr15">
            <h2 class="hLh30 txtOf mt15">
              <span class="c-fff fsize24">{{course.title}}</span>
            </h2>
            <section class="c-attr-jg">
              <span class="c-fff">价格：</span>
              <b class="c-yellow" style="font-size:24px;">￥{{course.price}}</b>
            </section>
            <section class="c-attr-mt c-attr-undis">
              <span class="c-fff fsize14">主讲： {{teacher.name}}&nbsp;&nbsp;&nbsp;</span>
            </section>
            <section class="c-attr-mt of">
              <span class="ml10 vam">
                <em class="icon18 scIcon"></em>
                <a class="c-fff vam" title="收藏" href="#">收藏</a>
              </span>
            </section>
            <section class="c-attr-mt">
              <a href="#" v-if="Number(course.price)===0" @click="createOrder" title="立即观看" class="comm-btn c-btn-3">立即购买</a>
            </section>
            <section class="c-attr-mt">
              <a href="#" v-if="Number(course.price)!=0" @click="createOrder" title="立即购买" class="comm-btn c-btn-3">立即购买</a>
            </section>
          </section>
          
        </aside>
        <aside class="thr-attr-box">
          <ol class="thr-attr-ol clearfix">
            <li>
              <p>&nbsp;</p>
              <aside>
                <span class="c-fff f-fM">购买数</span>
                <br />
                <h6 class="c-fff f-fM mt10">{{course.buyCount}}</h6>
              </aside>
            </li>
            <li>
              <p>&nbsp;</p>
              <aside>
                <span class="c-fff f-fM">课时数</span>
                <br />
                <h6 class="c-fff f-fM mt10">{{course.lessonNum}}</h6>
              </aside>
            </li>
            <li>
              <p>&nbsp;</p>
              <aside>
                <span class="c-fff f-fM">浏览数</span>
                <br />
                <h6 class="c-fff f-fM mt10">{{course.viewCount}}</h6>
              </aside>
            </li>
          </ol>
        </aside>
        <div class="clear"></div>
      </div>
      <!-- /课程封面介绍 -->
      <div class="mt20 c-infor-box">
        <article class="fl col-7">
          <section class="mr30">
            <div class="i-box">
              <div>
                <section id="c-i-tabTitle" class="c-infor-tabTitle c-tab-title">
                  <a name="c-i" class="current" title="课程详情">课程详情123</a>
                </section>
              </div>
              <article class="ml10 mr10 pt20">
                <div>
                  <h6 class="c-i-content c-infor-title">
                    <span>课程介绍</span>
                  </h6>
                  <div class="course-txt-body-wrap">
                    <section class="course-txt-body">
                      <p v-html="description.description">{{description.description}}</p>
                    </section>
                  </div>
                </div>
                <!-- /课程介绍 -->
                <div class="mt50">
                  <h6 class="c-g-content c-infor-title">
                    <span>课程大纲</span>
                  </h6>
                  <section class="mt20">
                    <div class="lh-menu-wrap">
                      <menu id="lh-menu" class="lh-menu mt10 mr10">
                        <ul>
                          <!-- 文件目录 -->
                          <li
                            class="lh-menu-stair"
                            v-for="(chapter) in chapterList"
                            :key="chapter.id"
                          >
                            <a href="javascript: void(0)" :title="chapter.title" class="current-1">
                              <em class="lh-menu-i-1 icon18 mr10"></em>
                              {{chapter.title}}
                            </a>
                            <ol class="lh-menu-ol" style="display: block;">
                              <li
                                class="lh-menu-second ml30"
                                v-for="video in chapter.videoVoList"
                                :key="video.id"
                              >
                                <a
                                  :href="'/play/'+video.videoSourceId"
                                  :title="video.title"
                                  target="_blank"
                                >
                                  <span class="fr">
                                    <i class="free-icon vam mr10">免费试听</i>
                                  </span>
                                  <em class="lh-menu-i-2 icon16 mr5">&nbsp;</em>
                                  {{video.title}}
                                </a>
                              </li>
                            </ol>
                          </li>
                        </ul>
                      </menu>
                    </div>
                  </section>
                </div>
                <!-- /课程大纲 -->
              </article>

              <!-- 课程评论 开始 -->
              <div class="mt50 commentHtml">
                <div>
                  <h6 class="c-c-content c-infor-title" id="i-art-comment">
                    <span class="commentTitle">课程评论</span>
                  </h6>
                  <section class="lh-bj-list pr mt20 replyhtml">
                    <ul>
                      <li class="unBr">
                        <aside class="noter-pic">
                          <img
                            width="50"
                            height="50"
                            class="picImg"
                            src="~/assets/img/avatar-boy.gif"
                          />
                        </aside>
                        <div class="of">
                          <section class="n-reply-wrap">
                            <fieldset>
                              <textarea
                                name
                                v-model="comment.content"
                                placeholder="输入您要评论的文字"
                                id="commentContent"
                              ></textarea>
                            </fieldset>
                            <p class="of mt5 tar pl10 pr10">
                              <span class="fl">
                                <tt class="c-red commentContentmeg" style="display: none;"></tt>
                              </span>
                              <input
                                type="button"
                                @click="addComment()"
                                value="回复"
                                class="lh-reply-btn"
                              />
                            </p>
                          </section>
                        </div>
                      </li>
                    </ul>
                  </section>
                  <section class>
                    <section class="question-list lh-bj-list pr">
                      <ul class="pr10">
                        <li v-for="(comment,index) in data" v-bind:key="index">
                          <aside class="noter-pic">
                            <img width="50" height="50" class="picImg" :src="comment.avatar" />
                          </aside>
                          <div class="of">
                            <span class="fl">
                              <font class="fsize12 c-blue">{{comment.nickname}}</font>
                              <font class="fsize12 c-999 ml5">评论：</font>
                            </span>
                          </div>
                          <div class="noter-txt mt5">
                            <p>{{comment.content}}</p>
                          </div>
                          <div class="of mt5">
                            <span class="fr">
                              <font class="fsize12 c-999 ml5">{{comment.gmtCreate}}</font>
                            </span>
                          </div>
                        </li>
                      </ul>
                    </section>
                  </section>
                  <!-- 课程评论结束 -->
                  <!-- 公共分页 开始 -->
                  <!-- 分页 @current-change相当于绑定了一个单机函数getList,
                  框架已经封装好了方法不用加括号或者参数自动传参-->
                  <el-pagination
                    :current-page="current"
                    :page-size="size"
                    :total="total"
                    style="padding: 30px 0; text-align: center;"
                    layout="total, prev, pager, next, jumper"
                    @current-change="getList"
                  />
                  <!-- 公共分页 结束 -->
                </div>
              </div>
            </div>
          </section>
        </article>
        <aside class="fl col-3">
          <div class="i-box">
            <div>
              <section class="c-infor-tabTitle c-tab-title">
                <a href="#">主讲讲师</a>
              </section>
              <section class="stud-act-list">
                <ul style="height: auto;">
                  <li>
                    <div class="u-face">
                      <a href="#">
                        <img :src="teacher.avatar" width="50" height="50" :alt="teacher.name" />
                      </a>
                    </div>
                    <section class="hLh30 txtOf">
                      <a class="c-333 fsize16 fl" :href="'/teacher/'+teacher.id">{{teacher.name}}</a>
                    </section>
                    <section class="hLh20 txtOf">
                      <span class="c-999">{{teacher.intro}}</span>
                    </section>
                  </li>
                </ul>
              </section>
            </div>
          </div>
        </aside>
        <div class="clear"></div>
      </div>
    </section>
    <!-- /课程详情 结束 -->
  </div>
</template>

<script>
import course from "@/api/course";
import order from "@/api/order";
export default {
  data() {
    return {
      teacher: {},
      course: {},
      chapterList: [],
      description: {},
      videoList: [],
      comment: {},
      current: 1,
      size: 5,
      total: 0,
      data: {}
    };
  },
  created() {
    this.init();
    this.getList();
    // this.initVideoList();
  },
  methods: {
    //创建订单跳转页面
    createOrder(){
      // console.log(this.course.id)
      order.createOrder(this.course.id).then(response => {
            if(response.data.success){
              //用打开新页面的方式跳转
              let routeData = this.$router.resolve({
                    path: `/order/${response.data.data.orderId}`
                })
              // this.$router.push({ path: '/order/'+ response.data.data.orderId })
              console.log(routeData)
              window.open(routeData.href,'_blank')
            }
        })
    
    },
    //饿了么分页专用函数
    getList(current = 1) {
      this.current = current;
      this.getComment(this.current, this.size, this.$route.params.id);
    },
    getComment(current, size, id) {
      console.log(current);
      course.get_comment(current, size, id).then(response => {
        console.log(response);
        this.total = response.data.data.total;
        this.data = response.data.data.records;
      });
    },
    addComment() {
      this.comment.courseId = this.$route.params.id;
      this.comment.teacherId = this.teacher.id;
      course.save_comment(this.comment).then(response => {
        if (response.data.code != 20000) {
          this.$message.error("评论失败");
          this.getList();
        } else {
          this.$message({
            message: "评论成功",
            type: "success"
          });
          this.comment.content = "";
          this.getList();
        }
      });
    },
    init() {
      var courseId = this.$route.params.id;
      course.getDetailedInfo(courseId).then(response => {
        this.teacher = response.data.data.teacher;
        this.course = response.data.data.course;
        this.chapterList = response.data.data.chapterList;
        this.description = response.data.data.description;
      });
    }
    // initVideoList() {
    //   this.videoList = this.chapterList.videoVoList;
    // }
  }
};
</script>
<style>
.图片固定大小 {
  width: 700px;
  height: 330px;
}
</style>
