import request from '@/utils/request'

export default {

    //从后端获取播放凭证
    getPlayAuth(id) {
        return request({
            url: `/eduvod/getPlayAuth/${id}`,
            method: 'get'
        })
    }

}