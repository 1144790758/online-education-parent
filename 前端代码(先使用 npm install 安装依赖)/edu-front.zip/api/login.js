import request from '@/utils/request'

export default {
    login(member) {
        return request({
          url: `/serviceUC/ucenter-member/login`,
          method: 'post',
          data:member
        })
      },
      getUserInfo() {
        return request({
          url: `/serviceUC/ucenter-member/getUserInfo`,
          method: 'get',
        })
      },

}