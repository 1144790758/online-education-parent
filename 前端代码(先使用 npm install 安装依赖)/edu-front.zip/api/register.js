import request from '@/utils/request'

export default {
    //根据手机号码发送短信
    sendSms(mobile) {
      return request({
        url: `/servicesms/sendSms/${mobile}`,
        method: 'get'
      })
    },
    //用户注册
    submitRegister(formItem) {
      return request({
        url: `/serviceUC/ucenter-member/register`,
        method: 'post',
        data: formItem
      })
    }
  }