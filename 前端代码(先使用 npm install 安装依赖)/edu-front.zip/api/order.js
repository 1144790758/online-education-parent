import request from '@/utils/request'

export default{
    createOrder(courseId) {
        return request({
            url: `/orderservice/create_order/${courseId}`,
            method: 'post'
        })
    },
    getOrder(orderId) {
        return request({
            url: `/orderservice/get_order/${orderId}`,
            method: 'get'
        })
    },
}