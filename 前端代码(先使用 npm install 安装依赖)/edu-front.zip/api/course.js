import request from '@/utils/request'

export default {
    //查询8条热门课程,4个热门讲师
    getHot_index() {
        return request({
            url: `/eduservice/edu-course/hot_index`,
            method: 'get'
        })
    },
    //前台用于分页,条件查询显示所有课
    condition_query(current, size, CourseQueryVo) {
        return request({
            url: `/eduservice/edu-course/condition_query/${current}/${size}`,
            method: 'post',
            data: CourseQueryVo
        })
    },
    //发送请求查询后端的课程分类数据
    list_subject() {
        return request({
            //   url: '/EduService/edu-teacher',+'/current'+'/size' //要请求的后端路径
            url: `/eduservice/edu-subject/list_subject`,
            method: 'get',
        })
    },
    //前台显示课程详情,包括其章节信息
    getDetailedInfo(id) {
        return request({
            url: `/eduservice/edu-course/getDetailedInfo/${id}`,
            method: 'get',
        })
    },
    //分页查询当前课程的评论,把课程id传过来就行
    get_comment(current, size, id) {
        return request({
            url: `/eduservice/edu-course/get_comment/${current}/${size}/${id}`,
            method: 'get',
        })
    },
    save_comment(comment) {
        return request({
            url: `/eduservice/edu-course/save_comment`,
            method: 'post',
            data: comment
        })
    }
}