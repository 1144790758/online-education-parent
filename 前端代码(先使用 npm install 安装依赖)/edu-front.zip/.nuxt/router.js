import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _9676f68c = () => interopDefault(import('..\\pages\\course\\index.vue' /* webpackChunkName: "pages_course_index" */))
const _027cad4c = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _20295e9e = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages_order_index" */))
const _291bd810 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */))
const _4cb0065d = () => interopDefault(import('..\\pages\\teacher\\index.vue' /* webpackChunkName: "pages_teacher_index" */))
const _53406da2 = () => interopDefault(import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages_course__id" */))
const _4ef77efc = () => interopDefault(import('..\\pages\\order\\_oid.vue' /* webpackChunkName: "pages_order__oid" */))
const _7d76d52e = () => interopDefault(import('..\\pages\\play\\_id.vue' /* webpackChunkName: "pages_play__id" */))
const _5a55fc05 = () => interopDefault(import('..\\pages\\teacher\\_id.vue' /* webpackChunkName: "pages_teacher__id" */))
const _38d50a35 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/course",
    component: _9676f68c,
    name: "course"
  }, {
    path: "/login",
    component: _027cad4c,
    name: "login"
  }, {
    path: "/order",
    component: _20295e9e,
    name: "order"
  }, {
    path: "/register",
    component: _291bd810,
    name: "register"
  }, {
    path: "/teacher",
    component: _4cb0065d,
    name: "teacher"
  }, {
    path: "/course/:id",
    component: _53406da2,
    name: "course-id"
  }, {
    path: "/order/:oid",
    component: _4ef77efc,
    name: "order-oid"
  }, {
    path: "/play/:id?",
    component: _7d76d52e,
    name: "play-id"
  }, {
    path: "/teacher/:id",
    component: _5a55fc05,
    name: "teacher-id"
  }, {
    path: "/",
    component: _38d50a35,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
